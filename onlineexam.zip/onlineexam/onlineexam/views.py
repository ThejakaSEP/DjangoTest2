from django.shortcuts import render
from onlineexam.onlineexam.models import Exam

def examponline(request):
    results = Exam.objects.all()
    return render(request,'Index.html',{"Exam":results})
